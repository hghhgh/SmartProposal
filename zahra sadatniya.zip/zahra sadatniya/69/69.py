# Level name: BERT Objective–Method Alignment Checker

from transformers import AutoTokenizer, AutoModel
import torch
import torch.nn.functional as F


class BertSimilarity:
    def __init__(self, model_name="bert-base-uncased"):
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModel.from_pretrained(model_name)

    def encode(self, text: str):
        inputs = self.tokenizer(
            text,
            return_tensors="pt",
            truncation=True,
            padding=True,
            max_length=512
        )
        with torch.no_grad():
            outputs = self.model(**inputs)
        embeddings = outputs.last_hidden_state.mean(dim=1)
        return embeddings

    def similarity(self, text_a: str, text_b: str) -> float:
        emb_a = self.encode(text_a)
        emb_b = self.encode(text_b)
        score = F.cosine_similarity(emb_a, emb_b)
        return score.item()


if __name__ == "__main__":
    introduction = """
    The objective of this study is to evaluate the performance of machine learning
    models for text classification.
    """

    methods_results = """
    We applied several supervised learning algorithms and evaluated them using
    standard classification metrics such as accuracy and F1-score.
    """

    bert_sim = BertSimilarity()
    sim_score = bert_sim.similarity(introduction, methods_results)

    output = {
        "similarity_score": round(sim_score, 4)
    }

    print(output)
