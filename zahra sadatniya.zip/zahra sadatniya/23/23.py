
import re
from typing import List, Tuple


def extract_paragraphs_with_offsets(text: str) -> List[Tuple[str, int, int]]:
    """
    Returns list of (paragraph_text, start_offset, end_offset)
    """

    paragraphs = []

    # split by empty lines (one or more)
    pattern = re.compile(r'\n\s*\n', re.MULTILINE)

    last_index = 0

    for match in pattern.finditer(text):
        start = last_index
        end = match.start()

        paragraph = text[start:end].strip()

        if paragraph:
            real_start = text.find(paragraph, start, end)
            real_end = real_start + len(paragraph)
            paragraphs.append((paragraph, real_start, real_end))

        last_index = match.end()

    # last paragraph
    if last_index < len(text):
        paragraph = text[last_index:].strip()
        if paragraph:
            real_start = text.find(paragraph, last_index)
            real_end = real_start + len(paragraph)
            paragraphs.append((paragraph, real_start, real_end))

    return paragraphs



if __name__ == "__main__":

    sample_text = """This is paragraph one.
It has two lines.

This is paragraph two.

This is paragraph three.
Line two.
Line three.
"""

    result = extract_paragraphs_with_offsets(sample_text)

    print("Paragraph count:", len(result))
    print()

    for i, (p, s, e) in enumerate(result, 1):
        print(f"Paragraph {i}")
        print(f"Offset: ({s}, {e})")
        print(p)
        print("-" * 40)

    # validation
    expected_count = 3
    assert len(result) == expected_count, "Paragraph count mismatch"

    print("TEST PASSED")
