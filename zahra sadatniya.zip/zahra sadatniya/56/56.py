from typing import List, Callable, Dict, Any

class PipelineStep:
    def __init__(self, name: str, func: Callable[[Any], Any]):
        self.name = name
        self.func = func

    def run(self, data):
        return self.func(data)


class PreprocessingPipeline:
    def __init__(self):
        self.steps: List[PipelineStep] = []

    def add_step(self, name: str, func: Callable[[Any], Any]):
        self.steps.append(PipelineStep(name, func))

    def run(self, data):
        execution_order = []
        for step in self.steps:
            data = step.run(data)
            execution_order.append(step.name)
        return {
            "result": data,
            "execution_order": execution_order
        }


def normalize(text: str):
    return text.lower()

def tokenize(text: str):
    return text.split()

def pos_tag(tokens: List[str]):
    return [{"token": t, "pos": "NOUN"} for t in tokens]

def ner(tagged_tokens: List[Dict[str, str]]):
    return [{**t, "ner": "O"} for t in tagged_tokens]


if __name__ == "__main__":
    pipeline = PreprocessingPipeline()
    pipeline.add_step("normalize", normalize)
    pipeline.add_step("tokenize", tokenize)
    pipeline.add_step("pos", pos_tag)
    pipeline.add_step("ner", ner)

    input_text = "OpenAI Builds Powerful Models"
    output = pipeline.run(input_text)

    print(output)
