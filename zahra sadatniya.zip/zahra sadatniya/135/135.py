# Level name: Scheduled Model Training Job (Cron-Compatible)

import time
import datetime
import joblib
from sklearn.linear_model import SGDClassifier
from sklearn.feature_extraction.text import CountVectorizer
import numpy as np
import os


MODEL_PATH = "weekly_model.pkl"
VECTORIZER_PATH = "weekly_vectorizer.pkl"
LOG_PATH = "training_log.txt"


def load_or_init():
    if os.path.exists(MODEL_PATH) and os.path.exists(VECTORIZER_PATH):
        model = joblib.load(MODEL_PATH)
        vectorizer = joblib.load(VECTORIZER_PATH)
        is_new = False
    else:
        model = SGDClassifier(loss="log_loss", random_state=42)
        vectorizer = CountVectorizer()
        is_new = True
    return model, vectorizer, is_new


def get_new_data():
    texts = [
        "this product is excellent",
        "very bad experience",
        "average quality but good price"
    ]
    labels = [1, 0, 1]
    return texts, labels


def train_job():
    model, vectorizer, is_new = load_or_init()
    texts, labels = get_new_data()

    if is_new:
        X = vectorizer.fit_transform(texts)
        model.partial_fit(X, labels, classes=np.array([0, 1]))
    else:
        X = vectorizer.transform(texts)
        model.partial_fit(X, labels)

    joblib.dump(model, MODEL_PATH)
    joblib.dump(vectorizer, VECTORIZER_PATH)

    log_entry = f"[{datetime.datetime.now()}] Training job executed\n"
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write(log_entry)


if __name__ == "__main__":
    train_job()
    print("Training job executed successfully")
