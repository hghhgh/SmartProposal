# Level name: Extensible NLP Preprocessing Pipeline with Performance Benchmark

import time
import tracemalloc
from typing import List, Callable, Any, Dict


class PipelineStep:
    def __init__(self, name: str, func: Callable[[Any], Any]):
        self.name = name
        self.func = func

    def run(self, data):
        return self.func(data)


class PreprocessingPipeline:
    def __init__(self):
        self.steps: List[PipelineStep] = []

    def add_step(self, name: str, func: Callable[[Any], Any]):
        self.steps.append(PipelineStep(name, func))

    def run(self, data):
        execution_order = []
        for step in self.steps:
            data = step.run(data)
            execution_order.append(step.name)
        return data, execution_order


def normalize(text: str):
    return text.lower()


def tokenize(text: str):
    return text.split()


def pos_tag(tokens: List[str]):
    return [{"token": t, "pos": "NOUN"} for t in tokens]


def ner(tagged_tokens: List[Dict[str, str]]):
    return [{**t, "ner": "O"} for t in tagged_tokens]


if __name__ == "__main__":
    pipeline = PreprocessingPipeline()
    pipeline.add_step("normalize", normalize)
    pipeline.add_step("tokenize", tokenize)
    pipeline.add_step("pos", pos_tag)
    pipeline.add_step("ner", ner)

    text_10k = ("OpenAI builds powerful AI models. " * 300)[:10000]

    tracemalloc.start()
    start_time = time.perf_counter()

    result, order = pipeline.run(text_10k)

    end_time = time.perf_counter()
    current_mem, peak_mem = tracemalloc.get_traced_memory()
    tracemalloc.stop()

    output = {
        "execution_order": order,
        "execution_time_sec": round(end_time - start_time, 6),
        "memory_usage_kb": {
            "current": round(current_mem / 1024, 2),
            "peak": round(peak_mem / 1024, 2)
        },
        "output_sample": result[:5]
    }

    print(output)
