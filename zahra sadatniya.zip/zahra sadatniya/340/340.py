import numpy as np

def compute_dqi(
    completeness: float,
    accuracy: float,
    consistency: float,
    timeliness: float,
    validity: float,
    uniqueness: float,
    weights=None
) -> float:
    """
    Compute overall Data Quality Index (DQI)

    All input metrics must be in range [0, 1]
    """

    metrics = np.array([
        completeness,
        accuracy,
        consistency,
        timeliness,
        validity,
        uniqueness
    ])

    if weights is None:
        weights = np.ones(len(metrics)) / len(metrics)
    else:
        weights = np.array(weights)
        weights = weights / weights.sum()

    dqi = np.dot(metrics, weights)
    return float(dqi)


# Example usage
if __name__ == "__main__":
    dqi_score = compute_dqi(
        completeness=0.92,
        accuracy=0.88,
        consistency=0.90,
        timeliness=0.80,
        validity=0.95,
        uniqueness=0.93,
        weights=[0.2, 0.25, 0.15, 0.1, 0.2, 0.1]
    )
    print("DQI:", round(dqi_score, 4))
