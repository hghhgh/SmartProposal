
from transformers import AutoTokenizer, AutoModel
import torch
import torch.nn.functional as F


class BertEmbedder:
    def __init__(self, model_name="bert-base-uncased"):
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModel.from_pretrained(model_name)

    def embed(self, text: str) -> torch.Tensor:
        inputs = self.tokenizer(
            text,
            return_tensors="pt",
            truncation=True,
            padding=True,
            max_length=512
        )
        with torch.no_grad():
            outputs = self.model(**inputs)
        return outputs.last_hidden_state.mean(dim=1)


def cosine_sim(a: torch.Tensor, b: torch.Tensor) -> float:
    return F.cosine_similarity(a, b).item()


class SectionConsistencyChecker:
    def __init__(self, threshold: float = 0.6):
        self.embedder = BertEmbedder()
        self.threshold = threshold

    def check(self, introduction: str, objectives: str, results: str):
        emb_intro = self.embedder.embed(introduction)
        emb_obj = self.embedder.embed(objectives)
        emb_res = self.embedder.embed(results)

        sim_intro_obj = cosine_sim(emb_intro, emb_obj)
        sim_obj_res = cosine_sim(emb_obj, emb_res)
        sim_intro_res = cosine_sim(emb_intro, emb_res)

        warnings = []
        if sim_intro_obj < self.threshold:
            warnings.append("Low semantic alignment between introduction and objectives")
        if sim_obj_res < self.threshold:
            warnings.append("Low semantic alignment between objectives and results")
        if sim_intro_res < self.threshold:
            warnings.append("Low semantic alignment between introduction and results")

        return {
            "similarity_scores": {
                "intro_objectives": round(sim_intro_obj, 4),
                "objectives_results": round(sim_obj_res, 4),
                "intro_results": round(sim_intro_res, 4),
            },
            "warnings": warnings
        }


if __name__ == "__main__":
    introduction = """
    This paper aims to investigate the effectiveness of deep learning models
    for sentiment analysis in social media texts.
    """

    objectives = """
    The main objective is to evaluate transformer-based architectures
    for classifying sentiment polarity.
    """

    results = """
    Experimental results show that transformer models outperform
    traditional machine learning approaches in sentiment classification.
    """

    checker = SectionConsistencyChecker(threshold=0.65)
    output = checker.check(introduction, objectives, results)

    print(output)

