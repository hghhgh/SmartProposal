# Level name: Causal Relation Detection for Argument Quality Assessment

import random
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report


class CausalRelationDetector:
    def __init__(self):
        self.pipeline = Pipeline([
            ("tfidf", TfidfVectorizer(
                ngram_range=(1, 2),
                stop_words="english"
            )),
            ("clf", LogisticRegression(max_iter=300))
        ])

    def train(self, texts, labels):
        self.pipeline.fit(texts, labels)

    def predict(self, texts):
        return self.pipeline.predict(texts)

    def predict_proba(self, texts):
        return self.pipeline.predict_proba(texts)


# ===================== SYNTHETIC DATASET =====================
def generate_synthetic_data(n=50):
    causal_templates = [
        "Because {A}, {B}.",
        "{B} happened because {A}.",
        "{A} therefore {B}.",
        "{B} as a result of {A}."
    ]

    non_causal_templates = [
        "{A}. {B}.",
        "{A} and {B}.",
        "{A}. Also, {B}.",
        "{B} is mentioned with {A}."
    ]

    causes = ["the temperature increased", "the model was trained longer", "data quality improved"]
    effects = ["performance improved", "accuracy increased", "results became better"]

    texts, labels = [], []

    for _ in range(n):
        A = random.choice(causes)
        B = random.choice(effects)

        if random.random() > 0.5:
            tpl = random.choice(causal_templates)
            texts.append(tpl.format(A=A, B=B))
            labels.append(1)  # causal
        else:
            tpl = random.choice(non_causal_templates)
            texts.append(tpl.format(A=A, B=B))
            labels.append(0)  # non-causal

    return texts, labels


if __name__ == "__main__":
    texts, labels = generate_synthetic_data(n=80)

    train_texts = texts[:60]
    train_labels = labels[:60]
    test_texts = texts[60:]
    test_labels = labels[60:]

    detector = CausalRelationDetector()
    detector.train(train_texts, train_labels)

    preds = detector.predict(test_texts)

    print(classification_report(
        test_labels,
        preds,
        target_names=["non-causal", "causal"]
    ))

    # Sample inference
    samples = [
        "Because the model was trained longer, accuracy increased.",
        "The model was trained longer. Accuracy increased."
    ]

    print("Predictions:", detector.predict(samples))
