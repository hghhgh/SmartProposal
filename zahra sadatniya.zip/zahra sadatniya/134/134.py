# Level name: Automatic Model Version Selector (F1 / BLEU)

from typing import Dict
from sklearn.metrics import f1_score
from nltk.translate.bleu_score import sentence_bleu


class ModelVersion:
    def __init__(self, name: str, predictions, references, task_type: str):
        self.name = name
        self.predictions = predictions
        self.references = references
        self.task_type = task_type  # "classification" or "generation"

    def evaluate(self) -> float:
        if self.task_type == "classification":
            return f1_score(self.references, self.predictions, average="macro")

        if self.task_type == "generation":
            scores = [
                sentence_bleu([ref.split()], pred.split())
                for pred, ref in zip(self.predictions, self.references)
            ]
            return sum(scores) / len(scores)

        raise ValueError("Unsupported task type")


class ModelSelector:
    def __init__(self, metric: str):
        self.metric = metric  # "f1" or "bleu"
        self.models: Dict[str, ModelVersion] = {}

    def add_model(self, model: ModelVersion):
        self.models[model.name] = model

    def select_best(self):
        results = {}
        for name, model in self.models.items():
            results[name] = model.evaluate()

        best_model = max(results, key=results.get)
        return {
            "metric": self.metric,
            "scores": {k: round(v, 4) for k, v in results.items()},
            "best_model": best_model,
            "best_score": round(results[best_model], 4)
        }


if __name__ == "__main__":
    # ---- Classification test (F1) ----
    model_v1 = ModelVersion(
        name="model_v1",
        predictions=[1, 0, 1, 1],
        references=[1, 0, 0, 1],
        task_type="classification"
    )

    model_v2 = ModelVersion(
        name="model_v2",
        predictions=[1, 0, 0, 1],
        references=[1, 0, 0, 1],
        task_type="classification"
    )

    selector_f1 = ModelSelector(metric="f1")
    selector_f1.add_model(model_v1)
    selector_f1.add_model(model_v2)

    f1_result = selector_f1.select_best()
    print("F1 Selection Result:", f1_result)

    # ---- Generation test (BLEU) ----
    gen_v1 = ModelVersion(
        name="gen_model_v1",
        predictions=["the cat sits", "a dog runs"],
        references=["the cat is sitting", "a dog runs fast"],
        task_type="generation"
    )

    gen_v2 = ModelVersion(
        name="gen_model_v2",
        predictions=["the cat is sitting", "a dog runs fast"],
        references=["the cat is sitting", "a dog runs fast"],
        task_type="generation"
    )

    selector_bleu = ModelSelector(metric="bleu")
    selector_bleu.add_model(gen_v1)
    selector_bleu.add_model(gen_v2)

    bleu_result = selector_bleu.select_best()
    print("BLEU Selection Result:", bleu_result)
