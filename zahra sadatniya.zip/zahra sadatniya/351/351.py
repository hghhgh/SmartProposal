
import re

ARABIC_TO_PERSIAN_CHARS = {
    "ي": "ی",
    "ك": "ک",
    "ة": "ه",
    "ؤ": "و",
    "إ": "ا",
    "أ": "ا",
    "ٱ": "ا",
    "ئ": "ی",
    "‌": " ",  # ZWNJ to space (optional)
}

PUNCTUATION_MAP = {
    "،": ",",
    "؛": ";",
    "؟": "?",
}

def normalize_persian_text(text: str) -> str:
    # Normalize Arabic characters to Persian
    for src, dst in ARABIC_TO_PERSIAN_CHARS.items():
        text = text.replace(src, dst)

    # Normalize punctuation
    for src, dst in PUNCTUATION_MAP.items():
        text = text.replace(src, dst)

    # Remove extra spaces
    text = re.sub(r"\s+", " ", text)

    # Remove spaces before punctuation
    text = re.sub(r"\s+([,.!?;:])", r"\1", text)

    # Remove spaces after opening brackets
    text = re.sub(r"([\(\[\{])\s+", r"\1", text)

    # Remove spaces before closing brackets
    text = re.sub(r"\s+([\)\]\}])", r"\1", text)

    return text.strip()


if __name__ == "__main__":
    sample = "سلام  ،   اين   يك  متن  تستي ؟"
    print(normalize_persian_text(sample))
