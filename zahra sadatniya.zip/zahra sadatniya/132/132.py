# Level name: Incremental Training and Model Comparison

import joblib
import numpy as np
from sklearn.linear_model import SGDClassifier
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics import accuracy_score


class IncrementalTextModel:
    def __init__(self, model_path="model.pkl", vectorizer_path="vectorizer.pkl"):
        self.model_path = model_path
        self.vectorizer_path = vectorizer_path

        try:
            self.model = joblib.load(model_path)
            self.vectorizer = joblib.load(vectorizer_path)
            self.is_new = False
        except FileNotFoundError:
            self.model = SGDClassifier(loss="log_loss", random_state=1)
            self.vectorizer = CountVectorizer()
            self.is_new = True

    def train(self, texts, labels):
        if self.is_new:
            X = self.vectorizer.fit_transform(texts)
            self.model.partial_fit(X, labels, classes=np.unique(labels))
            self.is_new = False
        else:
            X = self.vectorizer.transform(texts)
            self.model.partial_fit(X, labels)

        joblib.dump(self.model, self.model_path)
        joblib.dump(self.vectorizer, self.vectorizer_path)

    def evaluate(self, texts, labels):
        X = self.vectorizer.transform(texts)
        preds = self.model.predict(X)
        return accuracy_score(labels, preds)


if __name__ == "__main__":
    # old model test data
    test_texts = [
        "this movie was excellent",
        "terrible film with bad acting"
    ]
    test_labels = [1, 0]

    # new training data
    new_texts = [
        "amazing story and great visuals",
        "worst movie ever"
    ]
    new_labels = [1, 0]

    model = IncrementalTextModel()

    acc_before = model.evaluate(test_texts, test_labels) if not model.is_new else None
    model.train(new_texts, new_labels)
    acc_after = model.evaluate(test_texts, test_labels)

    output = {
        "accuracy_before_incremental_training": acc_before,
        "accuracy_after_incremental_training": acc_after
    }

    print(output)
