# Level name: Rule-Based Informal / Colloquial Sentence Detector

import re


class InformalSentenceDetector:
    def __init__(self):
        # Common informal patterns (English + Persian examples)
        self.rules = {
            "contractions": re.compile(r"\b(i'm|you're|we're|they're|can't|won't|gonna|wanna|gotta)\b", re.I),
            "slang_words": re.compile(r"\b(cool|lol|omg|dude|bro|btw|idk|imo)\b", re.I),
            "informal_punctuation": re.compile(r"[!]{2,}|[?]{2,}|\.{3,}"),
            "spoken_fillers": re.compile(r"\b(uh|umm|yeah|you know|like)\b", re.I),
            "persian_colloquial": re.compile(r"(میخوام|نمیدونم|آخه|چراا+|خیلیی+|اصن)", re.I),
        }

    def detect(self, sentence: str) -> dict:
        matches = {}

        for rule_name, pattern in self.rules.items():
            matches[rule_name] = bool(pattern.search(sentence))

        informal_score = sum(matches.values()) / len(matches)

        return {
            "sentence": sentence,
            "informal_score": round(informal_score, 3),
            "is_informal": informal_score >= 0.3,
            "matched_rules": [k for k, v in matches.items() if v]
        }


if __name__ == "__main__":
    detector = InformalSentenceDetector()

    samples = [
        "I’m gonna test this model, lol!",
        "The experiment was conducted under controlled conditions.",
        "من اصن نمیدونم چراا اینجوری شد!",
        "Results indicate a significant improvement."
    ]

    for s in samples:
        result = detector.detect(s)
        print(result)
