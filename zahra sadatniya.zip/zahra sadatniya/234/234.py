# Level name: Semantic Coherence via Sentence Embeddings

from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np


class SemanticCoherenceChecker:
    def __init__(self, model_name: str = "all-MiniLM-L6-v2"):
        self.model = SentenceTransformer(model_name)

    def encode(self, texts):
        return self.model.encode(texts, normalize_embeddings=True)

    def coherence_score(self, objectives: list[str], methods: list[str]) -> float:
        emb_obj = self.encode(objectives)
        emb_meth = self.encode(methods)

        sim_matrix = cosine_similarity(emb_obj, emb_meth)
        return float(np.mean(sim_matrix))



if __name__ == "__main__":
    objectives = [
        "The goal of this research is to improve text classification accuracy",
        "We aim to reduce computational cost of NLP models"
    ]

    methods = [
        "We fine-tune a lightweight transformer for text classification",
        "Model pruning is applied to reduce computation"
    ]

    checker = SemanticCoherenceChecker()
    score = checker.coherence_score(objectives, methods)

    print("Semantic Coherence Score:", round(score, 4))
