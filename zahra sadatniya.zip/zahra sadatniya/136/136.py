# Level name: Model Performance Guard with Automatic Rollback

import joblib
import os
from sklearn.metrics import f1_score


class ModelPerformanceGuard:
    def __init__(
        self,
        current_model_path: str,
        new_model_path: str,
        backup_model_path: str,
        min_relative_f1: float = 0.95
    ):
        self.current_model_path = current_model_path
        self.new_model_path = new_model_path
        self.backup_model_path = backup_model_path
        self.min_relative_f1 = min_relative_f1

    def load_model(self, path):
        return joblib.load(path)

    def evaluate(self, model, X, y):
        preds = model.predict(X)
        return f1_score(y, preds, average="macro")

    def compare_and_apply(self, X_eval, y_eval):
        current_model = self.load_model(self.current_model_path)
        new_model = self.load_model(self.new_model_path)

        f1_current = self.evaluate(current_model, X_eval, y_eval)
        f1_new = self.evaluate(new_model, X_eval, y_eval)

        decision = "kept_current_model"

        if f1_new >= self.min_relative_f1 * f1_current:
            joblib.dump(current_model, self.backup_model_path)
            joblib.dump(new_model, self.current_model_path)
            decision = "new_model_accepted"
        else:
            decision = "rollback_triggered"

        return {
            "f1_current": round(f1_current, 4),
            "f1_new": round(f1_new, 4),
            "threshold": round(self.min_relative_f1 * f1_current, 4),
            "decision": decision
        }


if __name__ == "__main__":
    # --- test setup ---
    from sklearn.linear_model import LogisticRegression
    from sklearn.feature_extraction.text import CountVectorizer

    texts = [
        "excellent movie",
        "bad acting",
        "great story",
        "terrible film"
    ]
    labels = [1, 0, 1, 0]

    vectorizer = CountVectorizer()
    X = vectorizer.fit_transform(texts)

    model_current = LogisticRegression(max_iter=200)
    model_current.fit(X, labels)

    model_new = LogisticRegression(max_iter=200)
    model_new.fit(X, [1, 1, 1, 0])  # intentionally worse

    joblib.dump(model_current, "current_model.pkl")
    joblib.dump(model_new, "new_model.pkl")

    guard = ModelPerformanceGuard(
        current_model_path="current_model.pkl",
        new_model_path="new_model.pkl",
        backup_model_path="backup_model.pkl",
        min_relative_f1=0.95
    )

    result = guard.compare_and_apply(X, labels)
    print(result)
