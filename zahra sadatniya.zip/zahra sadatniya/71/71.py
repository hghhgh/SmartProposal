# Level name: Scientific Reference Quality Analyzer

import re
from typing import List, Dict


class ReferenceAnalyzer:
    DOI_PATTERN = re.compile(r"10\.\d{4,9}/[-._;()/:A-Z0-9]+", re.I)
    YEAR_PATTERN = re.compile(r"\b(19|20)\d{2}\b")

    def __init__(self, min_references: int = 5):
        self.min_references = min_references

    def analyze(self, references: List[str]) -> Dict:
        warnings = []

        if len(references) < self.min_references:
            warnings.append("Insufficient number of references")

        analyzed = []
        for ref in references:
            has_year = bool(self.YEAR_PATTERN.search(ref))
            has_doi = bool(self.DOI_PATTERN.search(ref))
            is_complete = has_year and has_doi

            if not is_complete:
                warnings.append(f"Incomplete reference detected: {ref[:60]}...")

            analyzed.append({
                "reference": ref,
                "has_year": has_year,
                "has_doi": has_doi,
                "complete": is_complete
            })

        return {
            "total_references": len(references),
            "references": analyzed,
            "warnings": list(set(warnings))
        }


if __name__ == "__main__":
    references = [
        "Smith J. Deep Learning for NLP. Journal of AI, 2021. doi:10.1234/ai.5678",
        "Brown T. Language Models are Few-Shot Learners.",
        "Manning C. Foundations of Statistical NLP. MIT Press, 1999."
    ]

    analyzer = ReferenceAnalyzer(min_references=4)
    output = analyzer.analyze(references)

    print(output)
