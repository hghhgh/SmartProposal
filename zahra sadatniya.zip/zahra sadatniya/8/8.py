import time
import os
from typing import Dict, Tuple


class FileCache:
    """
    Simple file cache with TTL expiration.

    Features:
    - Cache file contents
    - TTL based expiration
    - Manual invalidate
    - Clear all cache
    """

    def __init__(self, ttl: float = 5.0):
        self.ttl = ttl
        self.cache: Dict[str, Tuple[bytes, float]] = {}

    def _is_valid(self, path: str) -> bool:
        if path not in self.cache:
            return False

        _, timestamp = self.cache[path]
        return (time.time() - timestamp) < self.ttl


    def read(self, path: str) -> bytes:
        """
        Read file with caching support
        """

        if not os.path.exists(path):
            raise FileNotFoundError(path)

        # return from cache if valid
        if self._is_valid(path):
            print("✅ Read from CACHE")
            return self.cache[path][0]

        # otherwise load from disk
        print("📂 Read from DISK")

        with open(path, "rb") as f:
            data = f.read()

        self.cache[path] = (data, time.time())
        return data

    def invalidate(self, path: str):
        """Remove one file from cache"""
        self.cache.pop(path, None)

    def clear(self):
        """Clear whole cache"""
        self.cache.clear()



# TEST SECTION (run directly)
# =========================================
if __name__ == "__main__":

    cache = FileCache(ttl=3)
    filename = "test.txt"

    # create sample file
    with open(filename, "w") as f:
        f.write("Hello Cache System!")

    print("\nFirst read (should be DISK)")
    cache.read(filename)

    print("\nSecond read (should be CACHE)")
    cache.read(filename)

    print("\nWaiting for TTL to expire...")
    time.sleep(4)

    print("\nThird read (should be DISK again)")
    cache.read(filename)
