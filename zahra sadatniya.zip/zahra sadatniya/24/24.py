from bs4 import BeautifulSoup
import json

def extract_headings(html: str):
    soup = BeautifulSoup(html, "html.parser")
    headings = []

    for tag in soup.find_all([f"h{i}" for i in range(1, 7)]):
        level = int(tag.name[1])
        headings.append({
            "level": level,
            "title": tag.get_text(strip=True)
        })

    return headings

def build_hierarchy(headings):
    root = []
    stack = []

    for h in headings:
        node = {**h, "children": []}

        while stack and stack[-1]["level"] >= node["level"]:
            stack.pop()

        if stack:
            stack[-1]["children"].append(node)
        else:
            root.append(node)

        stack.append(node)

    return root

if __name__ == "__main__":
    html_input = """
    <h1>Main Title</h1>
    <h2>Section 1</h2>
    <h3>Subsection 1.1</h3>
    <h2>Section 2</h2>
    <h4>Deep Topic</h4>
    """

    headings = extract_headings(html_input)
    structured = build_hierarchy(headings)
    print(json.dumps(structured, ensure_ascii=False, indent=2))
