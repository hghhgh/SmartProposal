

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import os

KEY_SIZE = 32  # 256-bit
NONCE_SIZE = 12


def generate_key():
    return os.urandom(KEY_SIZE)


def encrypt_file(input_path, output_path, key):
    with open(input_path, "rb") as f:
        data = f.read()

    nonce = os.urandom(NONCE_SIZE)
    aesgcm = AESGCM(key)
    ciphertext = aesgcm.encrypt(nonce, data, None)

    with open(output_path, "wb") as f:
        f.write(nonce + ciphertext)


def decrypt_file(input_path, output_path, key):
    with open(input_path, "rb") as f:
        raw = f.read()

    nonce = raw[:NONCE_SIZE]
    ciphertext = raw[NONCE_SIZE:]

    aesgcm = AESGCM(key)
    plaintext = aesgcm.decrypt(nonce, ciphertext, None)

    with open(output_path, "wb") as f:
        f.write(plaintext)



if __name__ == "__main__":
    key_valid = generate_key()
    key_invalid = generate_key()

    with open("secret.txt", "wb") as f:
        f.write(b"Top Secret Data")

    encrypt_file("secret.txt", "secret.enc", key_valid)

    decrypt_file("secret.enc", "secret.dec", key_valid)

    try:
        decrypt_file("secret.enc", "fail.dec", key_invalid)
    except Exception as e:
        print("Decryption failed with invalid key:", type(e).__name__)
