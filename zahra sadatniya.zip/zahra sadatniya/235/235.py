# Level name: Text Coherence via Perplexity + Sentence Similarity Graph

import numpy as np
import torch
from transformers import GPT2LMHeadModel, GPT2TokenizerFast
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity


class TextCoherenceScorer:
    def __init__(
        self,
        lm_name: str = "gpt2",
        emb_name: str = "all-MiniLM-L6-v2"
    ):
        self.tokenizer = GPT2TokenizerFast.from_pretrained(lm_name)
        self.lm = GPT2LMHeadModel.from_pretrained(lm_name)
        self.lm.eval()

        self.embedder = SentenceTransformer(emb_name)

    # -------- Perplexity --------
    def perplexity(self, text: str) -> float:
        enc = self.tokenizer(text, return_tensors="pt")
        with torch.no_grad():
            loss = self.lm(**enc, labels=enc["input_ids"]).loss
        return torch.exp(loss).item()

    # -------- Sentence Similarity Graph --------
    def sentence_similarity(self, sentences: list[str]) -> float:
        emb = self.embedder.encode(sentences, normalize_embeddings=True)
        sim = cosine_similarity(emb, emb)

        n = sim.shape[0]
        if n <= 1:
            return 0.0

        upper = sim[np.triu_indices(n, k=1)]
        return float(np.mean(upper))

    # -------- Final Coherence Score (0–1) --------
    def coherence_score(self, text: str) -> float:
        sentences = [s.strip() for s in text.split(".") if len(s.strip()) > 5]

        ppl = self.perplexity(text)
        sim = self.sentence_similarity(sentences)

        ppl_score = 1 / (1 + np.log(ppl))          # normalize perplexity
        coherence = 0.5 * ppl_score + 0.5 * sim   # combine

        return float(np.clip(coherence, 0, 1))


if __name__ == "__main__":
    logical_text = """
    The objective of this study is to improve text classification accuracy.
    We propose a transformer-based model.
    The model is trained on labeled datasets.
    Results show improved performance.
    """

    incoherent_text = """
    The objective of this study is to improve text classification accuracy.
    Bananas are yellow and cars need fuel.
    Quantum mechanics is difficult.
    I like pizza on weekends.
    """

    scorer = TextCoherenceScorer()

    score_logical = scorer.coherence_score(logical_text)
    score_incoherent = scorer.coherence_score(incoherent_text)

    print("Logical Text Coherence:", round(score_logical, 4))
    print("Incoherent Text Coherence:", round(score_incoherent, 4))
