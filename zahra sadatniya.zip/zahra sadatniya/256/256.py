# Level name: Persian Formal Text Rewriting Module (GPT-like via Seq2Seq)

from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
import torch


class PersianFormalRewriter:
    def __init__(
        self,
        model_name: str = "HooshvareLab/parsT5-base",
        max_length: int = 256
    ):
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForSeq2SeqLM.from_pretrained(model_name)
        self.max_length = max_length
        self.model.eval()

    def rewrite(self, text: str) -> str:
        prompt = f"متن محاوره‌ای را رسمی کن:\n{text}"

        inputs = self.tokenizer(
            prompt,
            return_tensors="pt",
            truncation=True,
            max_length=self.max_length
        )

        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_length=self.max_length,
                num_beams=4,
                early_stopping=True
            )

        return self.tokenizer.decode(
            outputs[0],
            skip_special_tokens=True
        )



if __name__ == "__main__":
    rewriter = PersianFormalRewriter()

    informal_text = "من اصن نمیدونم چرا این مدل انقدر بد جواب داد!"
    formal_text = rewriter.rewrite(informal_text)

    print("Original:", informal_text)
    print("Rewritten:", formal_text)
