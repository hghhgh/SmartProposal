import pandas as pd 
from langdetect import detect # _LangDetect: ماژول تشخیص خودکار زبان متن بر اساس الگوریتم‌های آماری
from hazm import Normalizer, word_tokenize # _Hazm: ابزار استاندارد برای پیش‌پردازش (نرمال‌سازی و قطعه‌بندی) متن فارسی
import statistics #  کتابخانه محاسبات آماری پایتون (برای تحلیل توزیع داده‌ها)

class DatasetQualityAudit:
    def __init__(self, file_path, text_column):
        #  بارگذاری فایل دیتاست از مسیر مشخص شده در قالب جدول را باید انجام دهیم 
        self.df = pd.read_csv(file_path)
        #  ذخیره نام ستونی که محتوای متنی در آن قرار دارد
        self.text_col = text_column
       #: ایجاد یک دیکشنری برای جمع‌آوری نتایج تمام آزمایش‌های کیفی
        self.report = {}

    def check_language_consistency(self):
        """بررسی میزان  زبان فارسی در دیتاست را در این قسمت بررسی میکینیم"""
        # : نیاز داریم که تعریف یک تابع کمکی برای بررسی زبان تک‌تک ردیف‌ها
        def is_persian(text):
            try:
                # _Detection: بازگردان 'True'  اگر زبان متن توسط مدل فارسی تشخیص داده شود
                return detect(str(text)) == 'fa'
            except:
                #  مدیریت خطا برای متون خالی یا کاراکترهای نامفهوم (برگشت False)
                return False
        
        #  اجرای تابع تشخیص زبان روی تمام سلول‌های ستون مورد نظر
        results = self.df[self.text_col].apply(is_persian)
        #محاسبه درصد ردیف‌های فارسی نسبت به کل داده‌ها
        self.report['persian_ratio'] = results.mean() * 100
        print(f"میزان انطباق با زبان فارسی: {self.report['persian_ratio']:.2f}%")

    def check_lexical_diversity(self):
        """سنجش تنوع واژگان (لغوی) (Type-Token Ratio)"""
        # Normalizer_Init: برای یکسان سازی حروف باید مقدار اپلیه را نرمالسازی کنیم
        normalizer = Normalizer()
        all_words = []
        
        # Word_Extraction: استخراج کلمات از تمام ردیف‌ها
        for text in self.df[self.text_col].dropna(): # نادیده گرفتن مقادیر خالی
            # Normalization_Tokenization: نرمال‌سازی متن و سپس تبدیل آن به لیست کلمات
            tokens = word_tokenize(normalizer.normalize(str(text)))
            all_words.extend(tokens)
            
        # #16_Unique_Words:   استفاده از مجموعه ست برای استخراج کلمات بدون تکرار
        unique_words = set(all_words)
        # محاسبه شاخص تنوع (تعداد کلمات منحصربه‌فرد تقسیم بر کل کلمات)
        diversity_score = len(unique_words) / len(all_words) if all_words else 0
        self.report['lexical_diversity'] = diversity_score
        print(f"شاخص تنوع لغوی: {diversity_score:.4f}")

    def detect_outliers(self):
        """شناسایی ناهنجاری‌ها متنی (متون بیش از حد کوتاه یا بلند)"""
        #_Length_Calculation: محاسبه طول هر رشته متنی در ستون هدف
        lengths = self.df[self.text_col].astype(str).str.len()
        # _Standard_Stats: محاسبه میانگین و انحراف معیار طول کل جملات
        mean_len = lengths.mean()
        std_len = lengths.std()
        
        
        outliers = self.df[abs(lengths - mean_len) > 3 * std_len]
        self.report['outliers_count'] = len(outliers)
        print(f"تعداد داده‌های پرت (Outliers): {len(outliers)}")

    def final_grade(self):
        """محاسبه نمره نهایی بر اساس وزن‌دهی به شاخص‌های مختلف"""
        score = 0
        # امتیازدهی ؛ اگر معیاری از حد نصاب بگذرد، امتیاز آن بخش اضافه می‌شود
        if self.report.get('persian_ratio', 0) > 90: score += 40
        if self.report.get('lexical_diversity', 0) > 0.05: score += 30
        if (self.report.get('outliers_count', 0) / len(self.df)) < 0.05: score += 30
        
        print(f"\nامتیاز نهایی کیفیت دیتاست: {score}/100")

# #22_Main_Process: بخش اجرایی برنامه
if __name__ == "__main__":
    # #23_Execution: نمونه‌سازی از کلاس و اجرای زنجیره‌ای تمام تست‌ها
    audit = DatasetQualityAudit('persian_llm_data.csv', 'content')
    audit.check_language_consistency()
    audit.check_lexical_diversity()
    audit.detect_outliers()
    audit.final_grade()
