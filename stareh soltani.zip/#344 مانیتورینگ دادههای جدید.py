import pandas as pd 
import datetime # _DateTime_Log: برای ثبت دقیق زمان و تاریخ هر رویداد در گزارش مانیتورینگ
import os 

class DataMonitor:
    def __init__(self, threshold=80.0):
        """باید مقدار دهی اولیه انجام دهیم تا به حد نصاب برسیم"""
        # _Threshold_Config: تعیین آستانه پذیرش؛ داده‌های با امتیاز کمتر از این عدد رد می‌شوند
        self.threshold = threshold 
        # #5_Log_File_Naming: تعیین نام فایل متنی برای ذخیذه کردن گزارش به آن نیاز داریم
        self.log_file = "monitoring_logs.txt" 

    def log_result(self, file_name, score, status):
        """در اینجا گزارش را ثبت میکنیم"""
        # Create_Timestamp: ایجاد برچسب زمانی برای مشخص شدن لحظه بررسی
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        #_File_Append:'a' باز کردن فایل در حالت  برای اضافه کردن گزارش جدید بدون پاک کردن قبلی‌ها
        with open(self.log_file, "a", encoding="utf-8") as f:
            # _Write_Log: نوشتن جزئیات شامل نام فایل، امتیاز و وضعیت نهایی در فایل گزارش
            f.write(f"[{timestamp}] File: {file_name} | Score: {score}% | Status: {status}\n")

    def monitor_new_batch(self, file_path, quality_score):
        """در این قسمت باید داده های ورودی را خودکار بررسی کنیم با استغاده از امتیاز دریافتی"""
        print(f"--- Monitoring Report for {file_path} ---")
        
        # _Comparison_Logic: مقایسه میکنیم اکتیاز دریافتی را با مقدار ترشولدی که در کلاس تعریف کردیم
        if quality_score >= self.threshold:
            # #10_Approval_State: اگر امتیاز کافی بود، وضعیت به 'تایید شده' تغییر می‌کند
            status = "APPROVED (تایید شده)"
            icon = "+"
            message = "Data is healthy and ready for training."
        else:
            # _Rejection_State: اگر امتیاز کمتر از حد بود، وضعیت 'رد شده' اعلام می‌شود
            status = "REJECTED (رد شده)"
            icon = "-"
            message = "Data is biased or low quality! Action required."

        #  نمایش نتیجه بررسی در خروجی  برای کاربر
        print(f"{icon} Status: {status}")
        print(f"Details: {message}")
        
        #  فراخوانی متد ذخیره‌سازی برای ثبت دائمی این رویداد در لاگ‌ها
        self.log_result(file_path, quality_score, status)

#بخش اجرا کد نوشته شده

if __name__ == "__main__":
    # #15_Watcher_Init: ساخت ناظر داده با حد ترشولد ۷۵ درصد
    watcher = DataMonitor(threshold=75.0)
    
    # : تعریف یک فایل فرضی و امتیازی که از ماژول کیفیت‌ دریافت میکینیم
    new_data = "new_dataset_feb_2026.csv"
    incoming_quality = 68.5 # این امتیاز کمتر از ۷۵ است و باید رد شود
    
    # #17_Start_Monitor: شروع عملیات پایش روی داده ورودی
    watcher.monitor_new_batch(new_data, incoming_quality)

