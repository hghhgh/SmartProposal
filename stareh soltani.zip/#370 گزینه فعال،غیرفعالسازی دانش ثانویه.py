# _Admin_Config: باید تعریف کنیم  تنظیمات ادمین در قالب یک دیکشنری (شبیه‌ساز دیتابیس پنل ادمین)
admin_settings = {
    "use_secondary_knowledge": True,  # گزینه فعال/غیرفعال‌سازی
    "model_name": "Persian-LLM-v1"
}

class QueryProcessor:
    def __init__(self, knowledge_base_content):
        # _Knowledge_Init:  انجام میدیم بارگذاری محتوای دانش در حافظه کلاس
        self.kb_content = knowledge_base_content

    def process_query(self, user_query):
        # بررسی وضعیت تنظیمات ادمین قبل از پاسخ‌دهی
        # چک می‌کنیم که آیا ادمین اجازه استفاده از دانش ثانویه را داده است یا خیر
        if admin_settings["use_secondary_knowledge"]:
            #4 ترکیب دانش ثانویه با سوال کاربر
            print(" [INFO] استفاده از دانش ثانویه فعال است.")
            final_prompt = f"Context: {self.kb_content}\nQuestion: {user_query}"
        else:
            # : نادیده گرفتن دانش و ارسال مستقیم سوال به مدل
            print("[INFO] دانش ثانویه غیرفعال است. استفاده از دانش داخلی مدل...")
            final_prompt = user_query
        
        return final_prompt

# باید شبیه‌سازی کنیم در این مرحله عملکرد دکمه فعال/غیرفعال‌سازی در پنل ادمین
def toggle_knowledge(status):
    admin_settings["use_secondary_knowledge"] = status
    state = "فعال" if status else "غیرفعال"
    print(f"\n [ADMIN] دانش ثانویه توسط ادمین {state} شد.\n")

# اجرای کد نوشته شده 
if __name__ == "__main__":
    my_kb = "پایتخت ایران تهران است و جمعیت آن حدود ۹ میلیون نفر است."
    processor = QueryProcessor(my_kb)

    # تست اول: در حالت فعال
    print("--- تست اول (فعال) ---")
    print("Prompt ارسال شده:", processor.process_query("جمعیت تهران چقدر است؟"))

    # #8_Toggle_Action: تغییر وضعیت در پنل ادمین
    toggle_knowledge(False)

    # تست دوم: در حالت غیرفعال
    print("--- تست دوم (غیرفعال) ---")
    print("Prompt ارسال شده:", processor.process_query("جمعیت تهران چقدر است؟"))

