import requests
import time # برای ایجاد وقفه بین تلاش‌های مجدد

class LMStudioClient:
    def __init__(self, base_url="http://localhost:1234/v1", timeout=5, retries=3):
        #  تنظیمات پایه شامل آدرس سرور، مهلت پاسخ و تعداد دفعات تلاش مجدد
        self.base_url = base_url
        self.timeout = timeout
        self.retries = retries

    def send_request(self, prompt):
        """ارسال درخواست به LM Studio با مدیریت خطا و Retry"""
        payload = {
            "model": "local-model",
            "messages": [{"role": "user", "content": prompt}]
        }

        # حلقه‌ای که به تعداد دفعات مجاز تلاش می‌کند
        for attempt in range(1, self.retries + 1):
            try:
                print(f"🔄 Attempt {attempt}/{self.retries}: Connecting to LM Studio...")
                
                #  ارسال درخواست با محدودیت زمانی مشخص
                response = requests.post(
                    f"{self.base_url}/chat/completions",
                    json=payload,
                    timeout=self.timeout
                )
                
                
                response.raise_for_status()
                return response.json()

            except (requests.exceptions.ConnectionError, requests.exceptions.Timeout) as e:
                #  مدیریت خطای قطع اتصال یا اتمام وقت
                print(f"⚠️ Warning: Connection failed (Attempt {attempt}).")
                if attempt < self.retries:
                    wait_time = attempt * 2 #  افزایش زمان انتظار بین هر تلاش
                    print(f"⏳ Waiting {wait_time} seconds before next retry...")
                    time.sleep(wait_time)
                else:
                    # #7_Final_Failure: اگر تمام تلاش‌ها با شکست مواجه شد
                    print("❌ Error: Maximum retries reached. LM Studio is unavailable.")
                    return None

# --- سناریوی تست (Simulation) ---
if __name__ == "__main__":
    # ایجاد کلاینت با ۳ بار تلاش مجدد و ۵ ثانیه تایم‌اوت
    client = LMStudioClient(timeout=5, retries=3)
    
    print("🚀 Starting request...")
    result = client.send_request("سلام، چطوری؟")
    
    if result:
        print("✅ Response received:", result['choices'][0]['message']['content'])
    else:
        print("🛑 Critical: Please check if LM Studio is running on port 1234.")

