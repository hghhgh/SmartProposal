
import time#  وارد کردن کتابخانه‌های پایش سیستم فایل و مدیریت زمان
import os
from watchdog.observers import Observer # ابزار نظارت بر تغییرات پوشه
from watchdog.events import FileSystemEventHandler # هندلر رویدادهای فایل

# #2_KnowledgeBase_Class: کلاس مدیریت داده‌های مدل را داریم:
class KnowledgeBase:
    def __init__(self, file_path):
        self.file_path = file_path
        self.data = ""
        self.load_data() # بارگذاری اولیه در هنگام شروع برنامه

    def load_data(self):
        # : منطق خواندن فیزیکی فایل از دیسک
        try:
            with open(self.file_path, "r", encoding="utf-8") as f:
                self.data = f.read()
            print(f"✅ [RELOAD] دانش جدید در ساعت {time.strftime('%H:%M:%S')} بارگذاری شد.")
        except Exception as e:
            print(f"❌ [ERROR] خطا در خواندن فایل: {e}")

#:الان نیاز داریم کلاس اختصاصی برایه تغییرات فایل
class ReloadHandler(FileSystemEventHandler):
    def __init__(self, kb_instance):
        self.kb = kb_instance

    def on_modified(self, event):
        #  تشخیص اینکه آیا دقیقاً فایل تغییر کرده است یا خیر
        if not event.is_directory and event.src_path.endswith(self.kb.file_path):
            print(f" [EVENT] تغییر در فایل {self.kb.file_path} شناسایی شد...")
            
            # #6_Test_Scenario_Wait: صبر ۵ ثانیه‌ای طبق سناریوی تست (اطمینان از ذخیره کامل)
            time.sleep(4) 
            self.kb.load_data()

# اجرای کد نوشته شد
if __name__ == "__main__":
    KNOWLEDGE_FILE = "knowledge.txt"

    # #8_Initial_File_Creation: ساخت فایل دانش اولیه در صورت عدم وجود
    if not os.path.exists(KNOWLEDGE_FILE):
        with open(KNOWLEDGE_FILE, "w", encoding="utf-8") as f:
            f.write("Knowledge Version 1.0 - Initialized")

    # #9_Instance_Startup: راه‌اندازی شیء پایگاه دانش
    kb = KnowledgeBase(KNOWLEDGE_FILE)

    # #10_Observer_Setup: تنظیمات مربوط به ناظر  در پس‌زمینه
    handler = ReloadHandler(kb)
    observer = Observer()
    observer.schedule(handler, path='.', recursive=False) # نظارت بر پوشه جاری
    observer.start()

    print(f" [READY] سیستم Hot-Reload فعال است. فایل '{KNOWLEDGE_FILE}' را تغییر دهید.")

    try:
        # #11_Service_Simulation: شبیه‌سازی فعالیت مداوم سرویس بدون ری‌استارت
        while True:
            print(f" دانش فعلی سیستم: {kb.data}")
            print("--- (سرویس در حال اجراست، منتظر تغییر فایل...) ---")
            time.sleep(5) # وقفه برای خوانایی خروجی در کنسول
            
    except KeyboardInterrupt:
        # #12_Clean_Exit: توقف امن ناظر در صورت خروج کاربر
        observer.stop()
        print("\n سیستم متوقف شد.")
    
    observer.join()
