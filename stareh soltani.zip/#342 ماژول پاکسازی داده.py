import pandas as pd
import re #  کتابخانه عبارات منظم برای جست‌وجو و جایگزینی الگوهای متنی پیچیده

class DataCleaner:
    def __init__(self, file_path):
        # دوباره بارگذاری دیتاست جدید را داریم
        self.df = pd.read_csv(file_path)
        print("داده‌ها با موفقیت بارگذاری شدند.")

    def remove_duplicates(self):
        """حذف داده‌های تکراری برای جلوگیری از Overfitting یا وزن‌دهی غلط به داده‌ها"""
        # باید  تعداد سطرهای اولیه را ذخیره کنیمکه برای برای محاسبه میزان داده‌های حذف شده
        initial_count = len(self.df)
        # _Drop_Duplicates: حذف سطور کاملاً مشابه؛ پارامتر inplace تغییرات را روی فایل اصلی اعمال می‌کند
        self.df.drop_duplicates(inplace=True)
        print(f"تعداد {initial_count - len(self.df)} سطر تکراری حذف شد.")

    def fix_nulls(self):
        """مدیریت مقادیر گمشده (Missing Values) که باعث کرش کردن مدل می‌شوند"""
        # جدا کردن ستون‌هایی که نوع داده آن‌ها عددی است
        numeric_cols = self.df.select_dtypes(include=['number']).columns
        #: جایگزینی مقادیر خالی (NaN) با میانگین همان ستون 
        self.df[numeric_cols] = self.df[numeric_cols].fillna(self.df[numeric_cols].mean())
        print("مقادیر خالی عددی با میانگین جایگزین شدند.")

    def remove_bias_words(self, column_name, bias_list):
        """خنثی‌سازی متن با شناسایی و سانسور کلمات حساس """
        # #8_Nested_Function: تعریف تابع داخلی برای پردازش متنی هر سلول
        def clean_text(text):
            if isinstance(text, str):
                for word in bias_list:
                    # #9_Regex_Sub: استفاده از الگوی \b برای پیدا کردن کلمه دقیق (نه بخشی از یک کلمه دیگر)
                    # جایگزینی با [CLEANED] برای حفظ ساختار جمله بدون انتقال سوگیری
                    text = re.sub(rf'\b{word}\b', '[CLEANED]', text, flags=re.IGNORECASE)
                return text
            return text
        
        #: اجرای تابع پاکسازی روی تمام ردیف‌های ستون انتخاب شده
        self.df[column_name] = self.df[column_name].apply(clean_text)
        print(f"پاکسازی سوگیری در ستون {column_name} انجام شد.")

    def save_clean_data(self, output_path):
        # _Export: خروجی گرفتن از دیتاست تمیز شده برای استفاده در مراحل آموزش مدل
        self.df.to_csv(output_path, index=False)
        print(f"فایل پاکسازی شده در {output_path} ذخیره شد.")


# استفاده از کد نوشته شده ---

if __name__ == "__main__":
    # #12_Bias_Dictionary: لیست کلمات هدف که می‌خواهیم از دیتاست حذف شوند
    biases = ["بهار", "مهتاب", "شب"] 
    
    # #13_Pipeline_Execution: اجرای مرحله‌به‌مرحله فرآیند پاکسازی (Pipeline)
    cleaner = DataCleaner('raw_data.csv')
    cleaner.remove_duplicates()
    cleaner.fix_nulls()
    cleaner.remove_bias_words('comments', biases)
    cleaner.save_clean_data('cleaned_data.csv')

