#339  بررسی تناقض در برچسب‌ها#727
#دو کاربر به یک نظر امتیاز می‌دهند: یکی می‌گوید «مثبت» و دیگری می‌گوید «منفی». این یک تناقض (Inconsistency) است.

import pandas as pd 

class InconsistencyDetector:
    def __init__(self, file_path):
        #  بارگذاری فایل حاوی بازخوردهای کاربران در قالب یک دیتافریم
        self.df = pd.read_csv(file_path)
        print("--- Inconsistency Detection Started ---")

    def find_conflicts(self, sample_id_col, label_col):
        """شناسایی نمونه‌هایی که کاربران درباره برچسب آن‌ها توافق ندارند"""
        
        # _Nunique_Count: گروه‌بندی داده‌ها بر اساس شناسه و شمردن تعداد برچسب‌های متفاوت برای هر شناسه
        label_counts = self.df.groupby(sample_id_col)[label_col].nunique()
        
        #_Conflict_Logic: پیدا کردن شناسه‌هایی که تعداد برچسب‌های منحصربه‌فرد آن‌ها بیشتر از ۱ است (نشانه تناقض)
        conflicted_ids = label_counts[label_counts > 1].index.tolist()
        
        # _Filter_Rows: جدا کردن تمام ردیف‌های مربوط به این شناسه‌های متناقض از جدول اصلی
        conflicts_df = self.df[self.df[sample_id_col].isin(conflicted_ids)]
        
        print(f"Found {len(conflicted_ids)} samples with inconsistent labels.")
        # Return_Conflicts: بازگرداندن دیتافریم حاوی موارد دارای تداخل برای بررسی
        return conflicts_df

    def calculate_agreement_rate(self, sample_id_col, label_col):
        """محاسبه درصد کلی توافق میان برچسب‌زنندگان (Inter-rater Agreement)"""
        
        # _Unique_Samples: محاسبه تعداد کل نمونه‌های منحصربه‌فرد موجود در فایل
        total_samples = self.df[sample_id_col].nunique()
        
        # _Get_Labels: تکرار گروه‌بندی برای بررسی وضعیت پایداری برچسب‌ها
        label_counts = self.df.groupby(sample_id_col)[label_col].nunique()
        
        #_Consistent_Count: شمردن نمونه‌هایی که دقیقاً ۱ برچسب دارند (همه کاربران روی یک نظر توافق داشته‌اند)
        consistent_samples = len(label_counts[label_counts == 1])
        
        # _ فرمول محاسبه نرخ توافق: (تعداد توافق شده / کل نمونه‌ها)* ۱۰۰
        agreement_rate = (consistent_samples / total_samples) * 100
        print(f"Overall User Agreement: {agreement_rate:.2f}%")
        return agreement_rate

