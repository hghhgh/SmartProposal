import datetime# کتابخانه‌های لازم برای مدیریت زمان 
import random # برای شبیه‌سازی خطاها در تست

#  دیتابیس فرضی برای ذخیره خطاها جهت نمایش در پنل ادمین
error_logs = []

class LMStudioMonitor:
    def __init__(self):
        self.status = "Healthy"

    def report_error(self, error_type, details):
        # را در این مرحلع بررسی کنم بایدثبت خطا با جزئیات و زمان دقیق وقوع
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")
        error_entry = {
            "time": timestamp,
            "type": error_type,
            "message": details
        }
        error_logs.append(error_entry)
        # _Status_Update: تغییر وضعیت کلی سیستم در پنل ادمین
        self.status = f"Critical Error: {error_type}"

    def simulate_request(self):
        # :  LM Studioشبیه‌سازی انواع خطاهای رایج در 
        error_chance = random.choice(["timeout", "loading", "success"])
        
        if error_chance == "timeout":
            # _Timeout_Error: خطایی که نشان می‌دهد پردازش GPU بیش از حد طول کشیده است
            self.report_error("TIMEOUT_ERROR", "LM Studio response exceeded 30 seconds.")
        elif error_chance == "loading":
            # خطایی که نشان می‌دهد مدل در  بارگذاری نشده است
            self.report_error("MODEL_LOADING_FAILED", "Model 'Persian-LLM' not found in active memory.")
        else:
            print(" Request successful!")

# #8_Admin_Panel_View: تابعی برای نمایش خروجی در داشبورد ادمین
def display_admin_dashboard(monitor):
    print("\n" + "="*40)
    print(f" ADMIN PANEL - SYSTEM STATUS: {monitor.status}")
    print("="*40)
    print("Recent Error Logs:")
    if not error_logs:
        print("No errors detected. System is running smoothly.")
    for log in error_logs[-5:]: # نمایش ۵ خطای آخر
        print(f" [{log['time']}] {log['type']}: {log['message']}")
    print("="*40 + "\n")

# #9_Main_Execution: اجرای سناریوی تست مانیتورینگ
if __name__ == "__main__":
    monitor = LMStudioMonitor()
    
    # شبیه‌سازی چند درخواست و ثبت خطاها
    print("🚀 Starting System Audit...")
    for _ in range(3):
        monitor.simulate_request()
    
    # #10_Final_Display: نمایش نتایج نهایی در پنل ادمین
    display_admin_dashboard(monitor)

